﻿param([ValidateSet('Install','Verify','Restore')][string]$Mode='Verify',[string]$GameDirectory)
$ErrorActionPreference='Stop'
if(!$GameDirectory){$GameDirectory=Read-Host '请输入 Welcome to Elk 游戏目录的完整路径'}
$GameDirectory=$GameDirectory.Trim().Trim([char]34)
$packageRoot=$PSScriptRoot
$manifest=Get-Content -Raw -LiteralPath (Join-Path $packageRoot 'manifest.json') | ConvertFrom-Json
if($manifest.schema -ne 1){throw 'Unsupported patch manifest'}
$gameRoot=[IO.Path]::GetFullPath($GameDirectory).TrimEnd('\')
if(!(Test-Path -LiteralPath (Join-Path $gameRoot 'Welcome to Elk.exe') -PathType Leaf)){throw 'Select the Welcome to Elk game directory'}
function Join-Safe($Root,$Relative){
 if([IO.Path]::IsPathRooted($Relative)){throw 'Absolute path in manifest'}
 $full=[IO.Path]::GetFullPath((Join-Path $Root $Relative))
 if(!$full.StartsWith($Root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Path escapes target root'}
 $cursor=$full
 while($cursor.Length -ge $Root.Length){
  if((Test-Path -LiteralPath $cursor) -and ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Reparse points are not supported'}
  if($cursor -eq $Root){break};$cursor=Split-Path $cursor -Parent
 }
 return $full
}
function Hash($Path){
 if(!(Test-Path -LiteralPath $Path -PathType Leaf)){return ''}
 $stream=[IO.File]::OpenRead($Path);$algorithm=[Security.Cryptography.SHA256]::Create()
 try{return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose();$algorithm.Dispose()}
}
function Assert-Hash($Path,$Expected){if((Hash $Path) -ne $Expected){throw ('SHA-256 mismatch: '+$Path)}}
function Write-Json($Path,$Value){[IO.File]::WriteAllText($Path,($Value | ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))}
$recordPath=Join-Safe $gameRoot '.WelcomeToElkCN\installation.json'
if($Mode -in @('Install','Verify')){
 foreach($f in $manifest.compatibility_files){Assert-Hash (Join-Safe $gameRoot $f.path) $f.sha256}
}
if($Mode -eq 'Verify'){
 foreach($f in $manifest.files){Assert-Hash (Join-Safe $gameRoot $f.path) $f.after_sha256}
 Write-Output ('Patch verified: '+$manifest.patch_id);exit 0
}
if($Mode -eq 'Restore'){
 if(!(Test-Path -LiteralPath $recordPath)){throw 'No installation record. Restore requires the backup created during installation; a fresh patch ZIP cannot restore originals.'}
 $record=Get-Content -Raw -LiteralPath $recordPath | ConvertFrom-Json
 if($record.patch_id -ne $manifest.patch_id){throw 'Installation record belongs to another patch version'}
 foreach($f in $record.files){
  $current=Hash (Join-Safe $gameRoot $f.path)
  $before=if($f.before_present){$f.before_sha256}else{''}
  if($current -notin @($f.after_sha256,$before)){throw ('Game file changed since installation; refusing to overwrite: '+$f.path)}
  if($f.before_present){Assert-Hash (Join-Safe $gameRoot $f.backup) $f.before_sha256}
 }
 foreach($f in $record.files){
  $target=Join-Safe $gameRoot $f.path
  if($f.before_present){Copy-Item -LiteralPath (Join-Safe $gameRoot $f.backup) -Destination $target;Assert-Hash $target $f.before_sha256}
  elseif(Test-Path -LiteralPath $target){Assert-Hash $target $f.after_sha256;Remove-Item -LiteralPath $target}
 }
 $record.state='restored';Write-Json $recordPath $record
 Write-Output 'Original game files restored and SHA-256 verified. Backups retained.';exit 0
}
$allInstalled=$true
foreach($f in $manifest.files){if((Hash (Join-Safe $gameRoot $f.path)) -ne $f.after_sha256){$allInstalled=$false}}
if($allInstalled){Write-Output ('Already installed and verified: '+$manifest.patch_id);exit 0}
foreach($f in $manifest.files){
 $target=Join-Safe $gameRoot $f.path
 if($f.kind -eq 'new'){if(Test-Path -LiteralPath $target){throw ('New patch file already exists; refusing to overwrite: '+$f.path)}}
 else{Assert-Hash $target $f.before_sha256}
}
if(Test-Path -LiteralPath $recordPath){
 $old=Get-Content -Raw -LiteralPath $recordPath | ConvertFrom-Json
 if($old.state -ne 'restored'){throw 'An active installation record exists. Restore that patch before installing another one.'}
 $history=Join-Safe $gameRoot ('.WelcomeToElkCN\records\'+[Guid]::NewGuid().ToString('N')+'.json')
 [IO.Directory]::CreateDirectory((Split-Path $history -Parent)) | Out-Null
 Copy-Item -LiteralPath $recordPath -Destination $history
}
$xdelta=Join-Safe $packageRoot $manifest.decoder.path
Assert-Hash $xdelta $manifest.decoder.sha256
foreach($f in $manifest.files){Assert-Hash (Join-Safe $packageRoot $f.patch) $f.patch_sha256}
$run=[Guid]::NewGuid().ToString('N')
$staging=Join-Safe $gameRoot ('.WelcomeToElkCN\staging\'+$run)
$backupRoot='.WelcomeToElkCN\backups\'+$run
[IO.Directory]::CreateDirectory($staging) | Out-Null
$files=@()
foreach($f in $manifest.files){
 $staged=Join-Safe $staging $f.path;[IO.Directory]::CreateDirectory((Split-Path $staged -Parent)) | Out-Null
 if($f.kind -eq 'new'){Copy-Item -LiteralPath (Join-Safe $packageRoot $f.patch) -Destination $staged}
 else{
  & $xdelta -d -s (Join-Safe $gameRoot $f.path) (Join-Safe $packageRoot $f.patch) $staged
  if($LASTEXITCODE -ne 0){throw ('Delta decoding failed: '+$f.path)}
 }
 Assert-Hash $staged $f.after_sha256
 $backup=$null;$existed=$f.kind -ne 'new'
 if($existed){
  $backup=$backupRoot+'\'+$f.path
  $backupPath=Join-Safe $gameRoot $backup;[IO.Directory]::CreateDirectory((Split-Path $backupPath -Parent)) | Out-Null
  Copy-Item -LiteralPath (Join-Safe $gameRoot $f.path) -Destination $backupPath
  Assert-Hash $backupPath $f.before_sha256
 }
 $files+= [ordered]@{path=$f.path;before_present=$existed;before_sha256=$f.before_sha256;after_sha256=$f.after_sha256;backup=$backup}
}
$record=[ordered]@{patch_id=$manifest.patch_id;state='installing';created_utc=[DateTime]::UtcNow.ToString('o');files=$files}
Write-Json $recordPath $record
try{
 foreach($f in $files){Copy-Item -LiteralPath (Join-Safe $staging $f.path) -Destination (Join-Safe $gameRoot $f.path);Assert-Hash (Join-Safe $gameRoot $f.path) $f.after_sha256}
 $record.state='installed';Write-Json $recordPath $record
}catch{
 foreach($f in $files){
  $target=Join-Safe $gameRoot $f.path
  if($f.before_present){Copy-Item -LiteralPath (Join-Safe $gameRoot $f.backup) -Destination $target;Assert-Hash $target $f.before_sha256}
  elseif(Test-Path -LiteralPath $target){Assert-Hash $target $f.after_sha256;Remove-Item -LiteralPath $target}
 }
 $record.state='restored';Write-Json $recordPath $record;throw
}
Write-Output ('Patch installed and verified: '+$manifest.patch_id)
Write-Output 'Choose 简体中文 in the language menu (the former English slot). Saves were not edited by this installer.'
